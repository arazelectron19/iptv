export const SITE_ORIGIN = 'https://iptv-org.github.io'
export const DATA_DIR = './temp/data'
